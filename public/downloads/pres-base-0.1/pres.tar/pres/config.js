var config = {
  author: "Your Name",
  twitter: "twittertag",
  logo: "pres/logo.png"
};
