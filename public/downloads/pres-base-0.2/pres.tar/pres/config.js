var config = {
    // currently, showControls does not work nicely with showFooter
    showControls: false,
    // author, twitter and logo are only shown in case of showFooter
    showFooter: true,
    author: "Your Name",
    twitter: "twittertag",
    logo: "pres/logo.png"
};
