# Presentation

Create great web presentations

Use markdown or HTML

Edit on the fly with live reload

<a href="http://lab.hakim.se/reveal-js">More info</a>

---

## A slide

Press down now

-

## A slide below with a list
 - A thing
 - Another thing 
 - Three things

---
<!-- .slide: data-background="#555555" -->
## A slide with a different background

